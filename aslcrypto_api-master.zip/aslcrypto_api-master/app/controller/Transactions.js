
const Transaction = require('../models/transactions');
const ethers = require('ethers');


module.exports.SendTransaction = async (req, res) => {
    const { username, transactionId, fromWalletId, toWalletId, transferType } = req.body;

    // Basic validation checks
    if (!username || !transactionId || !fromWalletId || !toWalletId || !transferType) {
        return res.status(400).json({ success: false, error: 'All fields are required' });
    }


    try {
        const newTransaction = new Transaction({
            username,
            transactionId,
            fromWalletId,
            toWalletId,
            timestamp: new Date(),
            transferType
        });

        const savedTransaction = await newTransaction.save();
        res.status(201).json(savedTransaction);
    } catch (error) {
        console.error('Error creating transaction:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};

module.exports.FetchUserTransactions = async (req, res) => {
    const { username } = req.params;  // assuming the username is passed as a URL parameter

    // Basic validation checks
    if (!username) {
        return res.status(400).json({ success: false, error: 'Username is required' });
    }

    try {
        // Query the database for transactions associated with the username
        const userTransactions = await Transaction.find({ username });

        if (!userTransactions || userTransactions.length === 0) {
            return res.status(404).json({ success: false, error: 'No transactions found for this user' });
        }

        res.status(200).json(userTransactions);
    } catch (error) {
        console.error('Error fetching transactions:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};


module.exports.sendUSDTtransfer = async (req, res) => {
    const { fromAddress, toAddress, amount } = req.body;
    const { usdtContract, transferContract, decimals } = req.networkConfig;

    try {
        const amountInWei = ethers.utils.parseUnits(amount.toString(), decimals);
        const txData = transferContract.interface.encodeFunctionData("transferUSDT", [fromAddress, toAddress, amountInWei]);

        res.json({ success: true, txData });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: error.message });
    }
}