const mongoose = require('mongoose');

const stakingSchema = new mongoose.Schema({
    currency: { type: String, required: true },
    status: { type: String, required: true },
    minStakingAmount: { type: Number, required: true },
    maxStakingAmount: { type: Number, required: true },
    allowedDays: { type: [Number], required: true },
    allowedPercentages: { type: [Number], required: true }
});

const Staking = mongoose.model('Staking', stakingSchema);

module.exports = Staking;
